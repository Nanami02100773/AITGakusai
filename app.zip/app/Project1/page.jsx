"use client";
import "./page.css";
import React from "react";
import ProjectCard from "./components/ProjectCard";

export default function App() {

  const projects = [
    "スタンプラリー", "工科展", "クラブ展", "WAKUWAKU LAND",
    "MAKE", "脱出ゲーム", "献血", "楽市楽座", "トレゾール",
    "condort","Laugh & Music", "狂夜祭", "後夜祭"
  ];

  return (
    <div>
      <div className="scroll-area">
        
        <div className="project-list">
          {projects.map((title, idx) => (
            <ProjectCard key={idx} title={title} />
          ))}
        </div> 
      </div>
     
    </div>
  );
}
