import React, { useEffect, useRef } from "react";
import "./Carousel.css"; // Tailwindが主なので、このCSSを使うなら残してOK

const items = Array.from({ length: 8 }, (_, i) => ({
  id: i,
  title: `アイテム ${i + 1}`,
  imgUrl: `https://picsum.photos/seed/${i + 1}/400/300`
}));

const LoopingAutoCarousel = () => {
  const scrollRef = useRef(null);

  useEffect(() => {
    const container = scrollRef.current;
    if (!container) return;

    const scrollStep = 1;
    const interval = 20;

    const loop = setInterval(() => {
      container.scrollLeft += scrollStep;

      if (container.scrollLeft >= container.scrollWidth / 2) {
        container.scrollLeft = 0;
      }
    }, interval);

    return () => clearInterval(loop);
  }, []);

  const loopedItems = [...items, ...items];

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      <div
        ref={scrollRef}
        className="carousel-container flex overflow-x-scroll space-x-4"
      >
        {loopedItems.map((item, index) => (
          <div
            key={index}
            className="min-w-[240px] rounded-xl shadow-md overflow-hidden"
          >
            <div className="bg-gray-100">
              <img
                src={item.imgUrl}
                alt={item.title}
                className="w-full h-56 object-cover rounded-t-xl"
              />
              <div className="h-8" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default LoopingAutoCarousel;
