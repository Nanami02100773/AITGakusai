"use client";
import Link from "next/link";
import "./NoticeSection.css";

const NoticeSection = () => {
  return (
    <section className="notice-section">
      <h2 className="title">お知らせ</h2>
      <div className="box3">
        <ul>
          <li className="notice-item">
            <Link href="/home/notice/1">イベント開催予定：〇月〇日</Link>
          </li>
          <li className="notice-item">
            <Link href="/home/notice/2">新商品が追加されました！</Link>
          </li>
          <li className="notice-item">
            <Link href="/home/notice/3">メンテナンス情報：〇日深夜</Link>
          </li>
        </ul>
      </div>
    </section>
  );
};

export default NoticeSection;
